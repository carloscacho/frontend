'use client'
import { useRef, useState } from "react"
import { PiUploadSimple } from "react-icons/pi"

import TextInputWithButton from "@/shared/components/utils/TextInputWithButton"
import SortControl from "@/shared/components/utils/SortControl"
import ListItens from "@/shared/components/displays/ListItens"
import Hero from "@/shared/components/displays/Hero"
import PageContainer from "@/shared/components/displays/PageContainer"
import Modal from "@/shared/components/displays/Modal"
import PalestrantesModal from "@/modules/palestrantes/components/PalestrantesModal"
import CsvPalestrantesModal from "@/modules/palestrantes/components/CsvPalestrantesModal"
import ConfirmDialog from "@/shared/components/displays/ConfirmDialog"
import Button from "@/shared/components/utils/Button"
import { useAuth } from "@/shared/contexts/AuthContext"
import { usePalestrantes } from "@/modules/palestrantes/hooks/usePalestrantes"

export default function Page() {
  const { usuario } = useAuth()
  const isAdmin = usuario?.tipo === 1
  const isAuthorized = usuario?.tipo === 1 || usuario?.tipo === 4

  const refMdPalestrantes = useRef(null)
  const refMdConfirmation = useRef(null)
  const refMdCsvImport = useRef(null)

  const {
    normalizedList,
    searchTerm,
    setSearchTerm,
    sortOrder,
    setSortOrder,
    handleSave,
    handleDelete,
    confirmDelete,
    cancelDelete,
    editingItem,
    openEdit,
    openCreate,
    closeEdit,
    isEditing,
    eventoSelect,
    importCsv
  } = usePalestrantes()

  const onSave = async (data) => {
    const success = await handleSave(data)
    if (success) {
      refMdPalestrantes.current.close()
    }
  }

  const onDelete = (id) => {
    handleDelete(id)
    refMdConfirmation.current.showModal()
  }

  const onConfirmDelete = async () => {
    await confirmDelete()
    refMdConfirmation.current.close()
  }

  return (
    <PageContainer>
      <Hero title="Cadastro de palestrante" />
      <div className="my-3 mx-2 flex justify-between items-center gap-2">
        <TextInputWithButton
          placeholder="Digite para pesquisar ou cadastrar"
          type='text'
          value={searchTerm}
          onChange={setSearchTerm}
          onClick={() => {
            openCreate(searchTerm ? { nome: searchTerm } : null)
            refMdPalestrantes.current.showModal()
          }}
          hideButton={!isAuthorized}
        >
          <SortControl value={sortOrder} onChange={setSortOrder} />
        </TextInputWithButton>

        {/* CSV Import Button */}
        {isAuthorized && eventoSelect && (
          <Button
            mode="outline"
            color="info"
            className="gap-2 m-0"
            onClick={() => refMdCsvImport.current.showModal()}
            title="Importar palestrantes via CSV"
          >
            <PiUploadSimple size={20} />
            <span className="hidden md:inline">Importar CSV</span>
          </Button>
        )}
      </div>
      <div>
        <ListItens
          info="lista de palestrante cadastradas"
          list={normalizedList}
          deleteFunction={isAuthorized ? onDelete : null}
          editFunction={isAuthorized ? (item) => {
            openEdit(item)
            refMdPalestrantes.current.showModal()
          } : null}
          groupBy={(item) => {
            const paList = item.raw?.palestrante_atividade || []
            if (paList.length === 0) return "Sem atividades"

            const periods = new Set()
            
            paList.forEach(pa => {
              const da = pa.atividade?.data_atividade?.[0]
              if (da && da.hora) {
                const hour = new Date(da.hora).getUTCHours()
                if (hour < 12) periods.add("Matutino")
                else if (hour < 18) periods.add("Vespertino")
                else periods.add("Noturno")
              }
            })

            if (periods.size === 0) return "Sem cronograma"

            // The user approved "texto misto (ex: Matutino/Noturno)"
            const periodsArray = Array.from(periods).sort((a, b) => {
              const order = { "Matutino": 1, "Vespertino": 2, "Noturno": 3 }
              return order[a] - order[b]
            })

            return periodsArray.join(" / ")
          }}
          groupOrder={[
            "Matutino",
            "Vespertino",
            "Noturno",
            "Matutino / Vespertino",
            "Matutino / Noturno",
            "Vespertino / Noturno",
            "Matutino / Vespertino / Noturno",
            "Sem cronograma",
            "Sem atividades"
          ]}
        />
      </div>
      <Modal refModal={refMdPalestrantes}>
        <h3 className="font-bold text-2xl ml-2">
          {isEditing ? "Editar Palestrante" : "Cadastrar Novos Palestrantes"}
        </h3>
        <PalestrantesModal
          onClickCancelar={() => {
            refMdPalestrantes.current.close()
            closeEdit()
          }}
          onClickSalvar={onSave}
          initialData={editingItem}
        />
      </Modal>

      <CsvPalestrantesModal
        refModal={refMdCsvImport}
        evento={eventoSelect ? { id: eventoSelect.id_evento, nome: eventoSelect.nome } : null}
        onImport={importCsv}
        onClose={() => { }}
      />

      <ConfirmDialog
        refModal={refMdConfirmation}
        title="Deletar Palestrante"
        message="Tem certeza que deseja deletar este palestrante?"
        onConfirm={onConfirmDelete}
        onCancel={() => {
          refMdConfirmation.current.close()
          cancelDelete()
        }}
      />
    </PageContainer>
  )
}
